// Leet Companies - In-Page Problem Company Tags Injector
(function() {
  'use strict';

  let cachedProblemData = null;
  let isExpanded = false;
  let currentSlug = null;
  let isInjecting = false;

  const WEBSITE_BASE_URL = 'https://leetcompanies.netlify.app';

  async function loadData() {
    if (cachedProblemData) return cachedProblemData;
    try {
      const dataUrl = chrome.runtime.getURL('data/problem_companies.json');
      const res = await fetch(dataUrl);
      cachedProblemData = await res.json();
      return cachedProblemData;
    } catch (err) {
      console.error('[LeetCompanies] Failed to load company data:', err);
      return {};
    }
  }

  function getProblemSlugFromUrl() {
    const pathname = window.location.pathname;
    const match = pathname.match(/\/problems\/([^\/]+)/);
    return match ? match[1] : null;
  }

  function createWidgetElement(slug, problemInfo) {
    const widget = document.createElement('div');
    widget.className = 'lc-companies-widget';
    widget.id = 'lc-companies-injected-widget';

    const iconUrl = chrome.runtime.getURL('icons/icon-32.png');
    const companies = (problemInfo && problemInfo.c) ? [...problemInfo.c].sort((a, b) => (b.f || 0) - (a.f || 0)) : [];
    const totalCount = companies.length;

    let companiesHtml = '';
    if (totalCount === 0) {
      companiesHtml = '<div class="lc-no-data-note">No specific company frequency tag recorded for this problem yet.</div>';
    } else {
      const displayCount = isExpanded ? companies.length : Math.min(8, companies.length);
      const visibleList = companies.slice(0, displayCount);

      companiesHtml = '<div class="lc-widget-pills">' + visibleList.map(comp => {
        const freqText = comp.f ? `<span class="lc-company-freq">${comp.f}%</span>` : '';
        const targetUrl = `${WEBSITE_BASE_URL}/#company=${encodeURIComponent(comp.s || comp.n.toLowerCase().replace(/\s+/g, '-'))}`;
        return `<a href="${targetUrl}" target="_blank" rel="noopener noreferrer" class="lc-company-pill" title="Explore ${comp.n} interview questions on Leet Companies">${comp.n} ${freqText}</a>`;
      }).join('') + '</div>';
    }

    widget.innerHTML = `
      <div class="lc-widget-header">
        <a href="${WEBSITE_BASE_URL}" target="_blank" rel="noopener noreferrer" class="lc-widget-brand" title="Visit Leet Companies">
          <img src="${iconUrl}" alt="Leet Companies" class="lc-widget-icon" />
          <span class="lc-widget-title">Leet Companies</span>
          <span class="lc-azn-badge">BY AZN LABS</span>
        </a>
        <span class="lc-widget-stats">
          ${totalCount > 0 ? `Asked by <strong>${totalCount}</strong> Companies` : 'General Question'}
        </span>
      </div>

      ${companiesHtml}

      <div class="lc-widget-footer">
        <a href="${WEBSITE_BASE_URL}" target="_blank" rel="noopener noreferrer" class="lc-widget-link">
          <span>Explore 470+ Companies &amp; Overlap Matrix</span>
          <span>↗</span>
        </a>
        ${totalCount > 8 ? `
          <button type="button" class="lc-toggle-btn" id="lc-toggle-expand-btn">
            ${isExpanded ? '▲ Show Less' : `▼ Show All (${totalCount})`}
          </button>
        ` : ''}
      </div>
    `;

    const toggleBtn = widget.querySelector('#lc-toggle-expand-btn');
    if (toggleBtn) {
      toggleBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        isExpanded = !isExpanded;
        injectWidget();
      });
    }

    return widget;
  }

  async function injectWidget() {
    if (isInjecting) return;
    isInjecting = true;

    try {
      const slug = getProblemSlugFromUrl();
      if (!slug) return;

      const data = await loadData();
      const problemInfo = data[slug];

      // Remove existing injected widget if present
      const existing = document.getElementById('lc-companies-injected-widget');
      if (existing) existing.remove();

      // Find insertion targets across different LeetCode layout versions
      const targetSelectors = [
        '[data-track-load="description_content"]',
        'div[class*="description__"]',
        'div[class*="content__"]',
        'div.elfjS',
        '#qd-content',
        '.flexlayout__layout .flexlayout__tab',
        'div[class*="css-"][class*="question"]'
      ];

      let targetContainer = null;
      for (const sel of targetSelectors) {
        const el = document.querySelector(sel);
        if (el) {
          targetContainer = el;
          break;
        }
      }

      if (!targetContainer) {
        targetContainer = document.querySelector('div[class*="header__"]') || document.querySelector('main');
      }

      if (targetContainer) {
        const widget = createWidgetElement(slug, problemInfo);
        if (targetContainer.firstChild) {
          targetContainer.insertBefore(widget, targetContainer.firstChild);
        } else {
          targetContainer.appendChild(widget);
        }
        currentSlug = slug;
      }
    } finally {
      isInjecting = false;
    }
  }

  function checkUrlAndInject() {
    const slug = getProblemSlugFromUrl();
    if (slug && (slug !== currentSlug || !document.getElementById('lc-companies-injected-widget'))) {
      injectWidget();
    }
  }

  // Initial load
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      setTimeout(injectWidget, 600);
      setTimeout(injectWidget, 1800);
    });
  } else {
    setTimeout(injectWidget, 600);
    setTimeout(injectWidget, 1800);
  }

  // SPA Route Change Listener
  let lastUrl = location.href;
  const observer = new MutationObserver(() => {
    const currentUrl = location.href;
    if (currentUrl !== lastUrl) {
      lastUrl = currentUrl;
      isExpanded = false;
      setTimeout(checkUrlAndInject, 500);
    } else if (!document.getElementById('lc-companies-injected-widget') && getProblemSlugFromUrl()) {
      // Re-inject if DOM rebuilt by React
      checkUrlAndInject();
    }
  });

  observer.observe(document.body || document.documentElement, { subtree: true, childList: true });

  window.addEventListener('popstate', () => {
    setTimeout(checkUrlAndInject, 500);
  });
})();

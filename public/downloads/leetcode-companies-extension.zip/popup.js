document.addEventListener('DOMContentLoaded', async () => {
  const searchInput = document.getElementById('popup-search-input');
  const resultsContainer = document.getElementById('popup-results');
  const WEBSITE_BASE_URL = 'https://leetcompanies.netlify.app';

  let problemData = {};
  let companiesList = [];

  try {
    const res = await fetch('data/problem_companies.json');
    problemData = await res.json();
  } catch (err) {
    console.error('Failed to load extension data:', err);
  }

  // Extract unique companies
  const companySet = new Map();
  Object.values(problemData).forEach(prob => {
    if (prob.c) {
      prob.c.forEach(comp => {
        const count = (companySet.get(comp.n) || 0) + 1;
        companySet.set(comp.n, count);
      });
    }
  });

  companiesList = Array.from(companySet.entries()).map(([name, count]) => ({
    name,
    slug: name.toLowerCase().replace(/\s+/g, '-'),
    count
  })).sort((a, b) => b.count - a.count);

  searchInput.addEventListener('input', (e) => {
    const query = e.target.value.toLowerCase().trim();
    if (!query) {
      resultsContainer.innerHTML = '<div class="popup-empty-hint">Type above to search companies &amp; interview frequencies instantly.</div>';
      return;
    }

    // 1. Search matching companies
    const matchedCompanies = companiesList.filter(c => c.name.toLowerCase().includes(query)).slice(0, 5);
    
    // 2. Search matching problems
    const matchedProblems = Object.entries(problemData)
      .filter(([slug, p]) => (p.t && p.t.toLowerCase().includes(query)) || slug.includes(query))
      .slice(0, 5);

    if (matchedCompanies.length === 0 && matchedProblems.length === 0) {
      resultsContainer.innerHTML = '<div class="popup-empty-hint">No matches found. Try another search.</div>';
      return;
    }

    let html = '';

    if (matchedCompanies.length > 0) {
      html += matchedCompanies.map(c => `
        <a href="${WEBSITE_BASE_URL}/#company=${c.slug}" target="_blank" class="popup-result-item">
          <div>
            <div class="popup-result-title">🏢 ${c.name}</div>
            <div style="font-size:0.675rem; color:#9ca3af;">${c.count} Interview Problems</div>
          </div>
          <span class="popup-result-badge">Explore ↗</span>
        </a>
      `).join('');
    }

    if (matchedProblems.length > 0) {
      html += matchedProblems.map(([slug, p]) => `
        <a href="https://leetcode.com/problems/${slug}/" target="_blank" class="popup-result-item">
          <div>
            <div class="popup-result-title">💡 ${p.t || slug}</div>
            <div style="font-size:0.675rem; color:#9ca3af;">Asked by ${p.c ? p.c.length : 0} Companies</div>
          </div>
          <span class="popup-result-badge" style="color: #38bdf8;">Solve ↗</span>
        </a>
      `).join('');
    }

    resultsContainer.innerHTML = html;
  });
});

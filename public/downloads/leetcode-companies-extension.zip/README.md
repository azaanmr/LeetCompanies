<div align="center">
  <img src="icons/icon-128.png" alt="Leet Companies Logo" width="80" />
  <h1>Leet Companies Chrome Extension</h1>
  <p><strong>See Real Company Interview Frequency Tags Directly on Any LeetCode Problem</strong></p>

  <p>
    <a href="https://leetcompanies.netlify.app"><img src="https://img.shields.io/badge/Live_Web_App-leetcompanies.netlify.app-ffa116?style=for-the-badge&logo=googlechrome&logoColor=white" alt="Live On" /></a>
    <a href="https://github.com/azaanmr/LeetCompanies-Extension"><img src="https://img.shields.io/badge/GitHub-Repository-181717?style=for-the-badge&logo=github&logoColor=white" alt="GitHub" /></a>
    <img src="https://img.shields.io/badge/Manifest-V3-646cff?style=for-the-badge" alt="Manifest V3" />
    <img src="https://img.shields.io/badge/Storage-100%25_Offline-10b981?style=for-the-badge" alt="Offline" />
    <img src="https://img.shields.io/badge/License-MIT-blue?style=for-the-badge" alt="License" />
  </p>
</div>

---

## 🌟 Overview

**Leet Companies Chrome Extension** injects real company tags, interview occurrence frequencies, and direct deep-links directly onto [leetcode.com](https://leetcode.com) problem description pages.

Practice company-specific interview questions for Google, Meta, Amazon, Microsoft, Bloomberg, Goldman Sachs, and 470+ top companies with **0ms latency and 100% offline privacy**.

---

## ⚡ Features

* 🏷️ **In-Page Company Badges**: View top companies and occurrence percentages directly below LeetCode's problem headers.
* 🔍 **Toolbar Quick Search**: Search 470+ companies and problems instantly from your browser toolbar.
* 🚀 **1-Click Deep Links**: Jump straight into the full company question matrix on [Leet Companies](https://leetcompanies.netlify.app).
* 🔒 **100% Client-Side & Offline**: Bundled compact database. Zero tracking, zero logins, zero API latency.

---

## 🛠️ How to Load Unpacked Extension (Development)

1. Open Google Chrome and navigate to `chrome://extensions/`.
2. Enable **Developer mode** (toggle in the top-right corner).
3. Click **Load unpacked** and select this directory (`Leetcode-Companies-Extension`).
4. Open any problem on [leetcode.com/problems/two-sum/](https://leetcode.com/problems/two-sum/) to see the widget in action!

---

## 📱 More Apps by AZN Labs

* ⏰ **[Any Alarm: Hardcore Wake Up & GPS Commute](https://play.google.com/store/apps/details?id=com.aznenterprises.anyalarm)**
* 💰 **[NET Expense Manager](https://play.google.com/store/apps/details?id=com.aznenterprises.tracksmith)**
* 🎮 **[MineSaves: MCPE World Backup](https://play.google.com/store/apps/details?id=com.aznenterprises.mcpebackup)**

👉 **[View AZN Labs on Google Play](https://play.google.com/store/apps/developer?id=AZN+Enterprises)**

---

## ⚖️ Disclaimer

* This project is an independent open-source tool developed purely for educational and interview preparation purposes.
* "LeetCode" and related trademarks are the property of LeetCode LLC. This project is not affiliated with, endorsed by, or sponsored by LeetCode or any of the mentioned companies.
* All company names, logos, and trademarks mentioned belong to their respective holders.

---

## 📄 License

This project is licensed under the [MIT License](LICENSE).
